import json,pathlib,re,gzip,hashlib,collections,statistics,sys
log=pathlib.Path(sys.argv[1]);label=sys.argv[2]
p=pathlib.Path(re.search(r'spike-10k: (.+/result.json)',log.read_text()).group(1)).parent
r=json.loads((p/'result.json').read_text());root=pathlib.Path('docs/evidence/redis-lease-sizing');root.mkdir(parents=True,exist_ok=True)
def metrics(t):return {l.split()[0]:float(l.split()[1]) for l in t.splitlines() if l.startswith('flash_')}
rows=[]
for i,(b,a) in enumerate(zip(r['apiReplicaMetricsBefore'],r.get('apiReplicaMetricsAfter',[])),1):
 before,after=metrics(b),metrics(a);delta={k:v-before.get(k,0) for k,v in after.items()};rows.append((before,after,delta))
def duration(prefix,indices=None):
 ds=[rows[i][2] for i in (indices if indices is not None else range(len(rows)))];name='flash_'+prefix
 count=sum(d.get(name+'_count',0) for d in ds);total=sum(d.get(name+'_sum',0) for d in ds)
 keys=set().union(*(d.keys() for d in ds));buckets=sorted((float(k.split('le="')[1].split('"')[0]),sum(d.get(k,0) for d in ds)) for k in keys if k.startswith(name+'_bucket{') and '+Inf' not in k)
 maximum=max((rows[i][1].get(name+'_max',0) for i in (indices if indices is not None else range(len(rows)))),default=0)
 return {'count':int(count),'totalMs':total*1000,'meanMs':total/count*1000 if count else None,'maxMs':maximum*1000,'quantileUpperMs':{str(q):next((bound*1000 for bound,n in buckets if n>=count*q),None) if count else None for q in [.5,.95,.99]},'buckets':buckets}
statuses=collections.Counter(str(x.get('httpStatus')) for x in r['burst']['records'])
httpbusy=[int(d.get('flash_http_busy_total',0)) for _,_,d in rows];expired=[int(d.get('flash_redis_pool_acquire_expired_total',0)) for _,_,d in rows]
c=sum(d.get('flash_http_latency_seconds_count',0) for _,_,d in rows);t=sum(d.get('flash_http_latency_seconds_sum',0) for _,_,d in rows)
s={'project':p.parent.name,'startedAt':r['startedAt'],'poolSize':int(label.split('-')[0]),'apiReplicas':3,'workerReplicas':1,'passed':r['passed'],'runStatus':r['runStatus'],'error':r.get('error'),'dispatchLastMs':r['burst']['dispatchLastMs'],'validDispatch':r['burst']['validDispatch'],'orders':len(r['final']['orders']),'admissions':len(r['final']['entries']),'invariants':r['final']['invariants'],'orderLatencyMs':r['orderVisibility']['latencyMs'],'orderMaxMs':r['orderVisibility']['maxMs'],'httpStatuses':dict(statuses),'httpBusyPerApi':httpbusy,'redisAcquireExpiredPerApi':expired,'peakLeasesPerApi':[a.get('flash_redis_pool_active_peak') for _,a,_ in rows],'activeLeasesAfter':[a.get('flash_redis_pool_active') for _,a,_ in rows],'purchaseLease':duration('redis_purchase_lease_seconds'),'purchaseAcquire':duration('redis_purchase_acquire_seconds'),'leasePerApi':[duration('redis_purchase_lease_seconds',[i]) for i in range(len(rows))],'acquirePerApi':[duration('redis_purchase_acquire_seconds',[i]) for i in range(len(rows))],'apiMeanMs':t/c*1000 if c else None,'clientMeanMs':statistics.mean(x['completedMs']-x['dispatchMs'] for x in r['burst']['records'] if 'completedMs' in x),'completedResponses':sum('completedMs' in x for x in r['burst']['records']),'incompleteResponses':sum('completedMs' not in x for x in r['burst']['records']),'clientLatencyMs':r['burst']['latencyMs'],'pollErrors':[x for x in r['polls'] if x.get('httpStatus')!=200]}
(root/('pool-'+label+'-summary.json')).write_text(json.dumps(s,indent=2)+'\n')
manifest=json.loads((root/'manifest.json').read_text()) if (root/'manifest.json').exists() else []
for f,rel in [(f,pathlib.Path(p.parent.name)/p.name/f.name) for f in sorted(p.iterdir()) if f.is_file()]+[(log,pathlib.Path(log.name))]:
 data=f.read_bytes();out=root/(str(rel)+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(data,mtime=0));manifest.append({'path':str(rel)+'.gz','originalBytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for k in ['purchaseLease','purchaseAcquire']:
 s[k].pop('buckets',None)
for k in ['leasePerApi','acquirePerApi']:
 for row in s[k]:row.pop('buckets',None)
print(json.dumps(s,indent=2))
